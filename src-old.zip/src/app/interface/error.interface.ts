export type TErrorSource = {
  path: string | number;
  message: string;
}[];
