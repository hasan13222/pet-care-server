export const USER_ROLE = {
  admin: 'admin',
  user: 'user',
} as const;
