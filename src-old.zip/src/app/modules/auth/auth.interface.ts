export interface TChangePassword {
    email: string;
    oldPassword: string;
    newPassword: string;
}