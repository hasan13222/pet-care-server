export const POST_TYPE = {
    regular: 'regular',
    premium: 'premium',
  } as const;

  export const POST_CATEGORY = {
    tip: 'tip',
    story: 'story',
  } as const;
  