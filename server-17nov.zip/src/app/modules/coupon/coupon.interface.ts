export interface TCoupon {
  code: string;
  discount_percent: number;
}
